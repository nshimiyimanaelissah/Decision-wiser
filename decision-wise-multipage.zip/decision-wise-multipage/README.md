# DecisionWise multi-page starter

A multipage responsive site with a shared navigation, persistent light/dark theme, decision worksheet, account role descriptions, messaging preview, CITA Agency preview, and real server-side translation integration for English (`en`), French (`fr`), and Kinyarwanda (`rw`) using Google Cloud Translation.

## Requirements
- Node.js 18 or newer
- Google Cloud project with Cloud Translation API enabled
- Google Cloud Translation API key (billing may be required by Google)

## Run locally
1. Extract this ZIP.
2. Open a terminal in the `decision-wise-multipage` folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your real key in `.env`: `GOOGLE_TRANSLATE_API_KEY=your_key_here`
6. Run `npm start`.
7. Visit `http://localhost:3000`. Do not open the HTML files directly from File Explorer; the backend must run for translation.

Keep `.env` private and never place the API key in browser JavaScript or publish it to GitHub.

## Pages
Home, How it works, Decision workspace, Accounts, Languages, Messaging, About us, Login, and CITA Agency are separate HTML pages.

## Translation
The language selector sends marked text to the Node backend, which calls Google Cloud Translation. Only text marked `data-translate` is translated in this starter. User-entered content and unmarked items remain unchanged. Machine translation can be inaccurate, especially for technical, legal, medical, government, or sensitive wording; have important translations reviewed by a fluent speaker.

## Not production-ready yet
Real authentication, secure sessions, account verification, role enforcement, database storage, AI decision analysis, real messaging, contact requests, and confidential CITA case management are not implemented. Do not enter real passwords or confidential case details. Add and test these before deployment.
