import 'dotenv/config';
import pg from 'pg';
import { readFile } from 'node:fs/promises';
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
try {
  const sql = await readFile(new URL('./schema.sql', import.meta.url), 'utf8');
  await pool.query(sql);
  console.log('CITA Agency database schema initialized.');
} catch (err) {
  console.error('Database initialization failed:', err.message);
  process.exitCode = 1;
} finally { await pool.end(); }
