# CITA Agency — controlled-access platform starter

A full-stack starter for a CITA Agency collaboration platform, built around these confirmed decisions:

- **Two account pathways:** people seeking help can self-register; workers cannot self-register.
- **Administrator-invited workers only:** an administrator creates a one-time invitation link, valid for 72 hours. A worker activates an account using that link.
- **Role-based workspace:** administrator, mediator, security personnel, case manager, recruitment officer, supervisor, and help seeker roles.
- **Persistent cases and direct messaging:** PostgreSQL stores cases, notes, conversations, messages, invitations and audit events. Socket.IO provides live message delivery to authorized conversation members.
- **Access boundaries:** help seekers see their own cases and can message assigned staff; staff can see cases they created or are assigned to, while administrators/supervisors have broader oversight. Internal case notes are restricted to authorized staff assigned to the case, administrators, or supervisors.

## Important implementation boundary

This is a **working development foundation**, not a production-certified case-management system. The source includes real database-backed account registration/login, invitation acceptance, case submission/listing/assignment, persistent conversations/messages, Socket.IO membership checks, basic audit logging and a starter UI. It has not been independently security-audited or tested against a live deployment in this environment. Do not use it for real sensitive, emergency, legal, safeguarding, or security-critical cases until it has been reviewed and tested by qualified people.

Not yet implemented: outbound invitation email, password reset, two-factor authentication, full account settings/session revocation, attachment uploads, message search, per-case granular confidentiality rules beyond the current role/assignment checks, recruitment application workflow, translation integration, and operational monitoring/backup. Invitation links are displayed to an administrator and must be sent using a trusted channel until email delivery is configured. This app does not provide emergency response services.

## Requirements

- Node.js 20+
- PostgreSQL 14+
- A long random `SESSION_SECRET`

## Local setup

1. Copy `.env.example` to `.env` and set `DATABASE_URL`, `SESSION_SECRET`, `APP_BASE_URL`, and a strong initial administrator password (at least 16 characters).
2. Create a PostgreSQL database named `cita_agency` (or update `DATABASE_URL`).
3. Run:

   ```bash
   npm install
   npm run db:init
   npm start
   ```

4. Open `http://localhost:3000`.
5. Sign in with `BOOTSTRAP_ADMIN_EMAIL` and `BOOTSTRAP_ADMIN_PASSWORD` from `.env`. The first administrator is created only if no administrator exists. **Remove `BOOTSTRAP_ADMIN_PASSWORD` from the environment after the first admin has been created.**
6. From the administrator workspace, open **Invite a worker**. Copy the generated link and share it privately. Worker self-registration is not offered.

## Production deployment checklist

- Use HTTPS and set `COOKIE_SECURE=true`.
- Set a unique, secret `SESSION_SECRET`; do not commit `.env`.
- Use a managed PostgreSQL database with encrypted connections, least-privilege credentials, automated backups, and tested restoration.
- Configure email delivery before relying on invitations; add password recovery and MFA before storing sensitive records.
- Add CSRF protection, stronger origin policy, security headers/CSP, monitoring/alerting, data-retention rules, incident response, accessibility checks, and a qualified security/privacy review.
- Define case classification and access rules with CITA leadership and local legal/safeguarding professionals. A role name alone is not sufficient authorization for highly sensitive records.
- Do not use the sample bootstrap password or real people's sensitive information in development.

## Main API routes

- `POST /api/auth/register` — public registration for `help_seeker` only
- `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`
- `POST /api/admin/invitations` — administrator only
- `POST /api/auth/accept-invitation` — one-time invited worker onboarding
- `POST /api/cases`, `GET /api/cases`, `POST /api/cases/:id/assign`, `POST /api/cases/:id/notes`
- `GET /api/directory`
- `GET /api/conversations`, `POST /api/conversations`
- `GET /api/conversations/:id/messages`, `POST /api/conversations/:id/messages`
- `GET /api/health`

## Verify after setup

1. Run `npm run db:init` and start the server.
2. Visit `/api/health`; it should return `{"ok":true,"database":"connected"}`.
3. Register a help-seeker account. Confirm it receives the `help_seeker` role.
4. Sign in as administrator, create a worker invitation, and accept it in a private browser window.
5. Confirm a worker cannot use the public registration form to create a worker role.
6. Create a case as a help seeker, assign it to a worker, then test that only authorized users can access the case and its conversations.
7. Test message persistence by signing out/in and checking history. Test with two separate accounts for live message delivery.
