import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import { rateLimit } from 'express-rate-limit';
import { randomBytes, createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { Server as SocketIOServer } from 'socket.io';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const httpServer = createServer(app);
const io = new SocketIOServer(httpServer);
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined });
const PgSession = connectPgSimple(session);
const isProd = process.env.NODE_ENV === 'production';

if (!process.env.DATABASE_URL) console.warn('DATABASE_URL is missing. Configure .env before starting the app.');
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) console.warn('Set SESSION_SECRET to a random value at least 32 characters long.');
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '30kb' }));
app.use(express.urlencoded({ extended: false, limit: '30kb' }));
const sessionMiddleware = session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  name: 'cita.sid', secret: process.env.SESSION_SECRET || 'development-only-change-me-before-deployment',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true' || isProd, maxAge: 1000 * 60 * 60 * 8 }
});
app.use(sessionMiddleware);
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

const staffRoles = ['admin','mediator','security','case_manager','recruitment','supervisor'];
const hashToken = (token) => createHash('sha256').update(token).digest('hex');
const safeUser = (u) => ({ id: u.id, email: u.email, fullName: u.full_name, role: u.role, preferredLanguage: u.preferred_language });
const asyncRoute = (fn) => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
function requireAuth(req,res,next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Please sign in.' });
  pool.query('SELECT role,status FROM users WHERE id=$1',[req.session.userId]).then(({rows})=>{
    const user=rows[0];
    if(!user || user.status!=='active') return req.session.destroy(()=>res.status(401).json({error:'Your account is inactive. Please contact CITA support.'}));
    req.session.role=user.role;
    next();
  }).catch(next);
}
function requireRole(...roles) { return (req,res,next) => requireAuth(req,res,()=>{ if (!roles.includes(req.session.role)) return res.status(403).json({error:'You do not have permission to do that.'}); next(); }); }
async function audit(actorId, action, targetType = null, targetId = null, metadata = {}) { await pool.query('INSERT INTO audit_logs(actor_id,action,target_type,target_id,metadata) VALUES($1,$2,$3,$4,$5)', [actorId || null, action, targetType, targetId == null ? null : String(targetId), metadata]); }
async function canAccessConversation(userId, conversationId) { const r = await pool.query('SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2', [conversationId,userId]); return r.rowCount > 0; }

app.get('/api/health', asyncRoute(async (_req,res) => { await pool.query('SELECT 1'); res.json({ ok: true, database: 'connected' }); }));
app.get('/api/auth/me', asyncRoute(async (req,res) => {
  if (!req.session.userId) return res.json({ user: null });
  const { rows } = await pool.query('SELECT id,email,full_name,role,preferred_language,status FROM users WHERE id=$1', [req.session.userId]);
  if (!rows[0] || rows[0].status !== 'active') { req.session.destroy(() => {}); return res.json({ user: null }); }
  res.json({ user: safeUser(rows[0]) });
}));
app.post('/api/auth/register', rateLimit({ windowMs: 60*60*1000, limit: 8 }), asyncRoute(async (req,res) => {
  const fullName = String(req.body.fullName || '').trim(); const email = String(req.body.email || '').trim().toLowerCase(); const password = String(req.body.password || '');
  if (fullName.length < 2 || fullName.length > 120 || !/^\S+@\S+\.\S+$/.test(email) || password.length < 10 || password.length > 200) return res.status(400).json({error:'Enter your name, a valid email, and a password of at least 10 characters.'});
  const passwordHash = await bcrypt.hash(password, 12);
  try {
    const { rows } = await pool.query("INSERT INTO users(email,full_name,password_hash,role) VALUES($1,$2,$3,'help_seeker') RETURNING id,email,full_name,role,preferred_language", [email,fullName,passwordHash]);
    req.session.regenerate(async (err)=>{ if(err) return res.status(500).json({error:'Could not create a secure session.'}); req.session.userId=rows[0].id; req.session.role=rows[0].role; req.session.save(async saveErr=>{ if(saveErr) return res.status(500).json({error:'Could not save your session.'}); await audit(rows[0].id,'account.registered','user',rows[0].id); res.status(201).json({user:safeUser(rows[0])}); }); });
  } catch (e) { if (e.code === '23505') return res.status(409).json({error:'An account with that email already exists.'}); throw e; }
}));
app.post('/api/auth/login', rateLimit({ windowMs: 15*60*1000, limit: 10 }), asyncRoute(async (req,res) => {
  const email = String(req.body.email || '').trim().toLowerCase(); const password = String(req.body.password || '');
  const { rows } = await pool.query('SELECT * FROM users WHERE email=$1', [email]); const user = rows[0];
  if (!user || user.status !== 'active' || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:'Email or password is incorrect, or the account is inactive.'});
  req.session.regenerate((err) => { if (err) return res.status(500).json({error:'Could not create a secure session.'}); req.session.userId = user.id; req.session.role = user.role; req.session.save(async (saveErr) => { if (saveErr) return res.status(500).json({error:'Could not save your session.'}); await audit(user.id,'auth.login'); res.json({user:safeUser(user)}); }); });
}));
app.post('/api/auth/logout', requireAuth, asyncRoute(async (req,res) => { await audit(req.session.userId,'auth.logout'); req.session.destroy(() => res.json({ok:true})); }));

// Only administrators can issue invitations. Raw tokens are returned once to the admin UI; store/share them securely.
app.post('/api/admin/invitations', requireRole('admin'), asyncRoute(async (req,res) => {
  const email = String(req.body.email || '').trim().toLowerCase(); const fullName = String(req.body.fullName || '').trim(); const role = String(req.body.role || '');
  if (!/^\S+@\S+\.\S+$/.test(email) || fullName.length < 2 || !staffRoles.includes(role) || role === 'admin' && req.body.allowAdminInvite !== true) return res.status(400).json({error:'Provide a valid name, email, and permitted staff role. Admin invitations require explicit confirmation.'});
  const token = randomBytes(32).toString('base64url'); const tokenHash = hashToken(token); const expiresAt = new Date(Date.now() + 72*60*60*1000);
  await pool.query('INSERT INTO worker_invitations(email,full_name,role,token_hash,invited_by,expires_at) VALUES($1,$2,$3,$4,$5,$6)', [email,fullName,role,tokenHash,req.session.userId,expiresAt]);
  await audit(req.session.userId,'worker.invited','invitation',email,{role});
  res.status(201).json({message:'Invitation created. Share this one-time link with the worker through a trusted channel.', inviteUrl:`${process.env.APP_BASE_URL || 'http://localhost:3000'}/accept-invitation.html?token=${encodeURIComponent(token)}`, expiresAt});
}));
app.post('/api/auth/accept-invitation', rateLimit({windowMs:15*60*1000,limit:8}), asyncRoute(async (req,res) => {
  const token = String(req.body.token || ''); const password = String(req.body.password || '');
  if (token.length < 20 || password.length < 10 || password.length > 200) return res.status(400).json({error:'Invalid invitation or password. Use a password of at least 10 characters.'});
  const client = await pool.connect();
  try {
    await client.query('BEGIN'); const inv = await client.query('SELECT * FROM worker_invitations WHERE token_hash=$1 FOR UPDATE',[hashToken(token)]); const i = inv.rows[0];
    if (!i || i.accepted_at || new Date(i.expires_at) < new Date()) { await client.query('ROLLBACK'); return res.status(400).json({error:'This invitation is invalid, expired, or already used.'}); }
    const passwordHash = await bcrypt.hash(password,12);
    const created = await client.query('INSERT INTO users(email,full_name,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,email,full_name,role,preferred_language',[i.email,i.full_name,passwordHash,i.role]);
    await client.query('UPDATE worker_invitations SET accepted_at=NOW() WHERE id=$1',[i.id]); await client.query('INSERT INTO audit_logs(actor_id,action,target_type,target_id,metadata) VALUES($1,$2,$3,$4,$5)',[created.rows[0].id,'worker.invitation_accepted','invitation',i.id,JSON.stringify({role:i.role})]);
    await client.query('COMMIT'); req.session.userId=created.rows[0].id; req.session.role=created.rows[0].role; res.status(201).json({user:safeUser(created.rows[0])});
  } catch(e) { await client.query('ROLLBACK'); if (e.code==='23505') return res.status(409).json({error:'An account with that email already exists.'}); throw e; } finally { client.release(); }
}));

app.post('/api/cases', requireAuth, asyncRoute(async (req,res) => {
  const title=String(req.body.title||'').trim(); const description=String(req.body.description||'').trim(); const category=String(req.body.category||'general').slice(0,80); const sensitivity=['standard','confidential','restricted'].includes(req.body.sensitivity)?req.body.sensitivity:'confidential';
  if (title.length<4 || title.length>160 || description.length<10 || description.length>8000) return res.status(400).json({error:'Provide a title (4–160 characters) and a description (10–8000 characters).'});
  const caseNumber=`CITA-${Date.now().toString(36).toUpperCase()}-${randomBytes(2).toString('hex').toUpperCase()}`;
  const {rows}=await pool.query('INSERT INTO cases(case_number,created_by,title,description,category,sensitivity) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,case_number,title,description,category,status,created_at',[caseNumber,req.session.userId,title,description,category,sensitivity]);
  await audit(req.session.userId,'case.created','case',rows[0].id); res.status(201).json({case:rows[0]});
}));
app.get('/api/cases', requireAuth, asyncRoute(async (req,res) => {
  const {rows}=req.session.role==='admin'||req.session.role==='supervisor'
    ? await pool.query('SELECT c.id,c.case_number,c.title,c.category,c.status,c.sensitivity,c.created_at,u.full_name AS requester,a.full_name AS assignee FROM cases c JOIN users u ON u.id=c.created_by LEFT JOIN users a ON a.id=c.assigned_to ORDER BY c.created_at DESC LIMIT 200')
    : await pool.query('SELECT c.id,c.case_number,c.title,c.category,c.status,c.sensitivity,c.created_at,u.full_name AS requester,a.full_name AS assignee FROM cases c JOIN users u ON u.id=c.created_by LEFT JOIN users a ON a.id=c.assigned_to WHERE c.created_by=$1 OR c.assigned_to=$1 ORDER BY c.created_at DESC LIMIT 200',[req.session.userId]);
  res.json({cases:rows});
}));
app.post('/api/cases/:id/assign', requireRole('admin','supervisor','case_manager'), asyncRoute(async(req,res)=>{
  const assigneeId=Number(req.body.assigneeId); if(!Number.isInteger(assigneeId)) return res.status(400).json({error:'Choose a valid staff member.'});
  const staff=await pool.query('SELECT id FROM users WHERE id=$1 AND role=ANY($2::text[]) AND status=\'active\'',[assigneeId,staffRoles]); if(!staff.rowCount) return res.status(400).json({error:'Assignee must be an active CITA worker.'});
  const result=await pool.query('UPDATE cases SET assigned_to=$1,status=CASE WHEN status=\'new\' THEN \'under_review\' ELSE status END,updated_at=NOW() WHERE id=$2 RETURNING id,case_number,assigned_to,status',[assigneeId,req.params.id]);
  if(!result.rowCount) return res.status(404).json({error:'Case not found.'}); await audit(req.session.userId,'case.assigned','case',req.params.id,{assigneeId}); res.json({case:result.rows[0]});
}));
app.post('/api/cases/:id/notes', requireAuth, asyncRoute(async(req,res)=>{
  const note=String(req.body.note||'').trim(); if(note.length<1||note.length>5000) return res.status(400).json({error:'Note must be between 1 and 5000 characters.'});
  const c=await pool.query('SELECT id,created_by,assigned_to,sensitivity FROM cases WHERE id=$1',[req.params.id]); if(!c.rowCount) return res.status(404).json({error:'Case not found.'}); const item=c.rows[0];
  if(req.session.role==='help_seeker' || !(req.session.role==='admin'||req.session.role==='supervisor'||Number(item.assigned_to)===Number(req.session.userId))) return res.status(403).json({error:'Only authorized staff assigned to this case can add internal notes.'});
  const {rows}=await pool.query('INSERT INTO case_notes(case_id,author_id,note) VALUES($1,$2,$3) RETURNING id,note,created_at',[item.id,req.session.userId,note]); await audit(req.session.userId,'case.note_added','case',item.id); res.status(201).json({note:rows[0]});
}));

app.get('/api/directory', requireAuth, asyncRoute(async(req,res)=>{
  let rows;
  if(req.session.role==='help_seeker') {
    const result=await pool.query(`SELECT DISTINCT u.id,u.full_name,u.role FROM users u JOIN cases c ON c.assigned_to=u.id WHERE c.created_by=$1 AND u.status='active' ORDER BY u.full_name`,[req.session.userId]); rows=result.rows;
  } else {
    const result=await pool.query(`SELECT id,full_name,role FROM users WHERE status='active' AND id<>$1 ORDER BY full_name LIMIT 300`,[req.session.userId]); rows=result.rows;
  }
  res.json({users:rows});
}));

app.get('/api/conversations', requireAuth, asyncRoute(async(req,res)=>{
  const {rows}=await pool.query(`SELECT c.id,c.title,c.case_id,c.created_at, (SELECT body FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC LIMIT 1) AS last_message, (SELECT created_at FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC LIMIT 1) AS last_message_at FROM conversations c JOIN conversation_members cm ON cm.conversation_id=c.id WHERE cm.user_id=$1 ORDER BY COALESCE((SELECT created_at FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC LIMIT 1),c.created_at) DESC`,[req.session.userId]); res.json({conversations:rows});
}));
app.post('/api/conversations', requireAuth, asyncRoute(async(req,res)=>{
  const targetId=Number(req.body.userId); const title=String(req.body.title||'').trim().slice(0,160); const caseId=req.body.caseId?Number(req.body.caseId):null;
  if(!Number.isInteger(targetId)||targetId===Number(req.session.userId)) return res.status(400).json({error:'Choose another user to message.'});
  const target=await pool.query('SELECT id,role,status FROM users WHERE id=$1',[targetId]); if(!target.rowCount||target.rows[0].status!=='active') return res.status(404).json({error:'That user is not available.'});
  // People seeking help can only initiate contact with staff assigned to one of their cases or an authorized support role.
  if(req.session.role==='help_seeker') {
    const access=await pool.query("SELECT 1 FROM cases WHERE created_by=$1 AND assigned_to=$2",[req.session.userId,targetId]);
    if(!access.rowCount) return res.status(403).json({error:'You can message staff assigned to one of your cases. Submit a support request if you need an assignment.'});
  } else if(target.rows[0].role==='help_seeker' && !['admin','supervisor'].includes(req.session.role)) {
    const access=await pool.query("SELECT 1 FROM cases WHERE created_by=$1 AND assigned_to=$2",[targetId,req.session.userId]);
    if(!access.rowCount) return res.status(403).json({error:'You can initiate a conversation with a person seeking help only when you are assigned to one of their cases.'});
  }
  if(caseId) { const c=await pool.query('SELECT created_by,assigned_to FROM cases WHERE id=$1',[caseId]); if(!c.rowCount || !(Number(c.rows[0].created_by)===Number(req.session.userId)||Number(c.rows[0].assigned_to)===Number(req.session.userId)||req.session.role==='admin'||req.session.role==='supervisor')) return res.status(403).json({error:'You cannot start a conversation about this case.'}); }
  const client=await pool.connect(); try { await client.query('BEGIN'); const conv=await client.query('INSERT INTO conversations(title,created_by,case_id) VALUES($1,$2,$3) RETURNING id,title,case_id,created_at',[title||null,req.session.userId,caseId]); await client.query('INSERT INTO conversation_members(conversation_id,user_id) VALUES($1,$2),($1,$3)',[conv.rows[0].id,req.session.userId,targetId]); await client.query('COMMIT'); await audit(req.session.userId,'conversation.created','conversation',conv.rows[0].id); res.status(201).json({conversation:conv.rows[0]}); } catch(e){await client.query('ROLLBACK');throw e;} finally{client.release();}
}));
app.get('/api/conversations/:id/messages', requireAuth, asyncRoute(async(req,res)=>{
  if(!await canAccessConversation(req.session.userId,req.params.id)) return res.status(403).json({error:'You are not a member of this conversation.'});
  const {rows}=await pool.query('SELECT m.id,m.conversation_id,m.sender_id,m.body,m.created_at,u.full_name AS sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.conversation_id=$1 ORDER BY m.created_at ASC LIMIT 500',[req.params.id]); await pool.query('UPDATE conversation_members SET last_read_at=NOW() WHERE conversation_id=$1 AND user_id=$2',[req.params.id,req.session.userId]); res.json({messages:rows});
}));
async function persistMessage(userId, conversationId, body) {
  if(!await canAccessConversation(userId,conversationId)) throw Object.assign(new Error('You are not a member of this conversation.'),{status:403});
  const clean=String(body||'').trim(); if(clean.length<1||clean.length>5000) throw Object.assign(new Error('Message must be between 1 and 5000 characters.'),{status:400});
  const {rows}=await pool.query('INSERT INTO messages(conversation_id,sender_id,body) VALUES($1,$2,$3) RETURNING id,conversation_id,sender_id,body,created_at',[conversationId,userId,clean]); const user=await pool.query('SELECT full_name FROM users WHERE id=$1',[userId]); const message={...rows[0],sender_name:user.rows[0]?.full_name||'User'}; await audit(userId,'message.sent','conversation',conversationId); return message;
}
app.post('/api/conversations/:id/messages', requireAuth, asyncRoute(async(req,res)=>{ const message=await persistMessage(req.session.userId,Number(req.params.id),req.body.body); io.to(`conversation:${req.params.id}`).emit('message:new',message); res.status(201).json({message}); }));

// Socket.IO uses the same Express session middleware and checks membership before joining a room.
io.engine.use(sessionMiddleware);
io.use(async(socket,next)=>{ try { const s=socket.request.session; if(!s?.userId) return next(new Error('Authentication required')); const r=await pool.query('SELECT id,status FROM users WHERE id=$1',[s.userId]); if(!r.rowCount||r.rows[0].status!=='active') return next(new Error('Account inactive')); socket.data.userId=s.userId; next(); } catch(e){next(new Error('Could not verify session'));} });
io.on('connection',(socket)=>{
  socket.on('conversation:join',async({conversationId}={})=>{ try { if(await canAccessConversation(socket.data.userId,Number(conversationId))) socket.join(`conversation:${Number(conversationId)}`); } catch {} });
  socket.on('message:send',async({conversationId,body}={})=>{ try { const message=await persistMessage(socket.data.userId,Number(conversationId),body); io.to(`conversation:${Number(conversationId)}`).emit('message:new',message); } catch(e){socket.emit('message:error',{error:e.status?e.message:'Message could not be sent.'});} });
});

// Initial administrator bootstrap. Run once on a fresh installation, then remove the bootstrap credentials from the environment.
async function bootstrapAdmin(){
  const email=String(process.env.BOOTSTRAP_ADMIN_EMAIL||'').trim().toLowerCase(); const password=String(process.env.BOOTSTRAP_ADMIN_PASSWORD||'');
  if(!email||!password) return;
  const existing=await pool.query('SELECT id FROM users WHERE role=\'admin\' LIMIT 1'); if(existing.rowCount) return;
  if(password.length<16) { console.warn('Bootstrap admin password must be at least 16 characters; administrator was not created.'); return; }
  const hash=await bcrypt.hash(password,12); try { await pool.query("INSERT INTO users(email,full_name,password_hash,role) VALUES($1,'CITA Initial Administrator',$2,'admin')",[email,hash]); console.log('Initial administrator created. Remove BOOTSTRAP_ADMIN_PASSWORD from .env now.'); } catch(e) { if(e.code!=='23505') throw e; }
}
app.use('/api', (err,req,res,next)=>{ console.error(err); if(res.headersSent) return next(err); res.status(err.status||500).json({error:err.status?err.message:'Server error. Check server logs.'}); });
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=Number(process.env.PORT||3000);
try { await pool.query('SELECT 1'); await bootstrapAdmin(); httpServer.listen(port,()=>console.log(`CITA Agency running on http://localhost:${port}`)); }
catch(e){ console.error('Startup failed. Check DATABASE_URL and initialize schema.sql first.',e.message); process.exit(1); }
