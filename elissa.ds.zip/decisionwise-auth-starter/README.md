# DecisionWise authentication starter

This is a backend-connected starter, not a production-audited identity platform. It includes email/password registration and login, one-time password reset links, server sessions stored in PostgreSQL, Google/Microsoft/Yahoo OAuth strategies, and TOTP-based 2FA setup/verification.

## Requirements
- Node.js 20+
- PostgreSQL database
- SMTP email account/provider for password-reset delivery
- OAuth app credentials for any external sign-in provider you enable

## Run locally
1. Create a PostgreSQL database named `decisionwise`.
2. Run the schema: `psql "postgres://postgres:YOUR_PASSWORD@localhost:5432/decisionwise" -f schema.sql`
3. Copy `.env.example` to `.env` and set `DATABASE_URL` and a long random `SESSION_SECRET`.
4. For password reset, configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, and `EMAIL_FROM`.
5. Install and run:
   ```sh
   npm install
   npm start
   ```
6. Open `http://localhost:3000/login.html`.

## OAuth setup
Create web application credentials with the exact redirect URLs shown in `.env.example`. Put secrets only in `.env`; never commit `.env` to GitHub. If credentials are empty, the provider route reports that it is not configured. Provider profile/email behavior can vary by account type and provider policy, so test each configured provider before deployment.

**Proton:** This project does not fake a Proton identity login. A Proton address can be used as the email for a normal DecisionWise account. Add Proton identity sign-in only if Proton provides a supported provider flow for your use case.

## 2FA
A signed-in user opens `/security.html`, chooses “Set up 2FA”, scans the QR code in an authenticator app, and enters a current code to enable it. Password sign-in then asks for the authenticator code. Users should retain a secure recovery route; recovery codes and administrator-assisted account recovery are not implemented in this starter.

## Important before public launch
- This is a starter implementation and has **not** been security audited or integration-tested against your live credentials.
- Use HTTPS and set `COOKIE_SECURE=true` in production.
- Configure `APP_URL` to your real HTTPS domain.
- Keep `.env` out of version control; rotate any secret accidentally committed.
- Add CSRF protection appropriate to your deployment, email verification, recovery codes, account lockout/risk controls, audit logging, data retention rules, monitoring, and automated tests.
- OAuth linking is intentionally not automatic when the email matches an existing account; that avoids silently linking accounts based on email alone.
- Use a managed email service or SMTP server and verify password-reset emails arrive before relying on the flow.
- Do not use real sensitive personal data until the app has been reviewed and hardened.
