import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import pg from 'pg';
import nodemailer from 'nodemailer';
import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import MicrosoftStrategy from 'passport-microsoft';
import YahooStrategy from 'passport-yahoo-oauth2';
import { authenticator } from 'otplib';
import QRCode from 'qrcode';

const app = express();
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const PgSession = connectPgSimple(session);
const PORT = Number(process.env.PORT || 3000);
const APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.warn('WARNING: Set SESSION_SECRET to a random secret of at least 32 characters.');
}

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || 'development-only-change-this-secret-before-deploying',
  resave: false,
  saveUninitialized: false,
  name: 'dw.sid',
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.COOKIE_SECURE === 'true',
    maxAge: 1000 * 60 * 60 * 8
  }
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.static('public'));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const resetLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 5, standardHeaders: true, legacyHeaders: false });

function cleanEmail(value) {
  return String(value || '').trim().toLowerCase();
}
function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}
function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in first.' });
  next();
}
function publicUser(user) {
  return { id: user.id, email: user.email, displayName: user.display_name, twoFactorEnabled: user.two_factor_enabled };
}
async function findOrCreateOAuthUser({ email, name, provider, subject }) {
  if (!email) throw new Error('The provider did not return an email address.');
  const existingProvider = await pool.query(
    'SELECT * FROM users WHERE oauth_provider=$1 AND oauth_subject=$2',
    [provider, subject]
  );
  if (existingProvider.rows[0]) return existingProvider.rows[0];

  const existingEmail = await pool.query('SELECT * FROM users WHERE email=$1', [cleanEmail(email)]);
  if (existingEmail.rows[0]) {
    // Do not silently link an OAuth identity to an existing password account.
    throw new Error('An account with this email already exists. Sign in with your existing method first.');
  }
  const result = await pool.query(
    `INSERT INTO users (email, display_name, oauth_provider, oauth_subject)
     VALUES ($1,$2,$3,$4) RETURNING *`,
    [cleanEmail(email), name || '', provider, subject]
  );
  return result.rows[0];
}
passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
  try {
    const result = await pool.query('SELECT * FROM users WHERE id=$1', [id]);
    done(null, result.rows[0] || false);
  } catch (error) { done(error); }
});

if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use('google', new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: `${APP_URL}/auth/google/callback`,
    scope: ['profile', 'email']
  }, async (_accessToken, _refreshToken, profile, done) => {
    try {
      const email = profile.emails?.[0]?.value;
      const user = await findOrCreateOAuthUser({
        email, name: profile.displayName, provider: 'google', subject: profile.id
      });
      done(null, user);
    } catch (e) { done(e); }
  }));
}
if (process.env.MICROSOFT_CLIENT_ID && process.env.MICROSOFT_CLIENT_SECRET) {
  passport.use('microsoft', new MicrosoftStrategy({
    clientID: process.env.MICROSOFT_CLIENT_ID,
    clientSecret: process.env.MICROSOFT_CLIENT_SECRET,
    callbackURL: `${APP_URL}/auth/microsoft/callback`,
    scope: ['user.read'],
    tenant: 'common'
  }, async (_accessToken, _refreshToken, profile, done) => {
    try {
      const email = profile.emails?.[0]?.value || profile._json?.mail || profile._json?.userPrincipalName;
      const user = await findOrCreateOAuthUser({
        email, name: profile.displayName, provider: 'microsoft', subject: profile.id
      });
      done(null, user);
    } catch (e) { done(e); }
  }));
}
if (process.env.YAHOO_CLIENT_ID && process.env.YAHOO_CLIENT_SECRET) {
  passport.use('yahoo', new YahooStrategy({
    clientID: process.env.YAHOO_CLIENT_ID,
    clientSecret: process.env.YAHOO_CLIENT_SECRET,
    callbackURL: `${APP_URL}/auth/yahoo/callback`
  }, async (_accessToken, _refreshToken, profile, done) => {
    try {
      const email = profile.emails?.[0]?.value;
      const user = await findOrCreateOAuthUser({
        email, name: profile.displayName, provider: 'yahoo', subject: profile.id
      });
      done(null, user);
    } catch (e) { done(e); }
  }));
}

function providerStart(provider) {
  return (req, res, next) => {
    if (!passport._strategy(provider)) {
      return res.status(503).send(`${provider} sign-in is not configured yet. Add its client credentials to .env and restart the server.`);
    }
    passport.authenticate(provider, { session: true })(req, res, next);
  };
}
function providerCallback(provider) {
  return (req, res, next) => {
    if (!passport._strategy(provider)) return res.redirect('/login.html?error=provider_not_configured');
    passport.authenticate(provider, (err, user) => {
      if (err || !user) return res.redirect('/login.html?error=provider_signin_failed');
      req.logIn(user, (loginErr) => {
        if (loginErr) return next(loginErr);
        return res.redirect('/security.html');
      });
    })(req, res, next);
  };
}
for (const provider of ['google', 'microsoft', 'yahoo']) {
  app.get(`/auth/${provider}`, providerStart(provider));
  app.get(`/auth/${provider}/callback`, providerCallback(provider));
}

app.post('/api/auth/register', authLimiter, async (req, res) => {
  const email = cleanEmail(req.body.email);
  const password = String(req.body.password || '');
  const displayName = String(req.body.displayName || '').trim().slice(0, 100);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 12) return res.status(400).json({ error: 'Use a password with at least 12 characters.' });
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      'INSERT INTO users (email,password_hash,display_name) VALUES ($1,$2,$3) RETURNING *',
      [email, passwordHash, displayName]
    );
    req.logIn(result.rows[0], (err) => {
      if (err) return res.status(500).json({ error: 'Could not start your session.' });
      res.status(201).json({ user: publicUser(result.rows[0]) });
    });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'An account with that email already exists.' });
    console.error(e); res.status(500).json({ error: 'Could not create the account.' });
  }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  const email = cleanEmail(req.body.email);
  const password = String(req.body.password || '');
  try {
    const result = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
    const user = result.rows[0];
    if (!user?.password_hash || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Email or password is incorrect.' });
    }
    if (user.two_factor_enabled) {
      const code = String(req.body.twoFactorCode || '');
      if (!code) return res.status(200).json({ requiresTwoFactor: true, message: 'Enter your authenticator code to finish signing in.' });
      if (!authenticator.check(code, user.two_factor_secret)) return res.status(401).json({ error: 'The two-factor code is not valid.' });
    }
    req.logIn(user, (err) => {
      if (err) return res.status(500).json({ error: 'Could not start your session.' });
      res.json({ user: publicUser(user) });
    });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Sign-in failed.' }); }
});

app.post('/api/auth/logout', (req, res) => {
  req.logout((err) => {
    if (err) return res.status(500).json({ error: 'Could not sign out.' });
    req.session.destroy(() => res.clearCookie('dw.sid').json({ ok: true }));
  });
});

app.post('/api/auth/forgot-password', resetLimiter, async (req, res) => {
  const email = cleanEmail(req.body.email);
  // Generic response prevents account enumeration.
  const generic = { message: 'If an account exists for that address, a password-reset email will be sent.' };
  try {
    const result = await pool.query('SELECT id,email FROM users WHERE email=$1', [email]);
    const user = result.rows[0];
    if (user) {
      const rawToken = crypto.randomBytes(32).toString('hex');
      const expires = new Date(Date.now() + 30 * 60 * 1000);
      await pool.query(
        'INSERT INTO password_reset_tokens (user_id,token_hash,expires_at) VALUES ($1,$2,$3)',
        [user.id, hashToken(rawToken), expires]
      );
      if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587),
          secure: process.env.SMTP_SECURE === 'true',
          auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        });
        const link = `${APP_URL}/reset-password.html?token=${rawToken}`;
        await transporter.sendMail({
          from: process.env.EMAIL_FROM || 'DecisionWise <no-reply@example.com>',
          to: user.email, subject: 'Reset your DecisionWise password',
          text: `A password reset was requested. This link expires in 30 minutes: ${link}\nIf you did not request this, ignore this email.`
        });
      } else {
        console.warn('SMTP is not configured; reset email was not sent. Configure SMTP before real use.');
      }
    }
    res.json(generic);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Could not process the request right now.' }); }
});

app.post('/api/auth/reset-password', resetLimiter, async (req, res) => {
  const token = String(req.body.token || '');
  const password = String(req.body.password || '');
  if (password.length < 12) return res.status(400).json({ error: 'Use a password with at least 12 characters.' });
  if (!token) return res.status(400).json({ error: 'Reset link is missing or invalid.' });
  try {
    const found = await pool.query(
      `SELECT id,user_id FROM password_reset_tokens
       WHERE token_hash=$1 AND used_at IS NULL AND expires_at > NOW()`,
      [hashToken(token)]
    );
    const row = found.rows[0];
    if (!row) return res.status(400).json({ error: 'This reset link is invalid or expired. Request a new one.' });
    const passwordHash = await bcrypt.hash(password, 12);
    await pool.query('BEGIN');
    await pool.query('UPDATE users SET password_hash=$1 WHERE id=$2', [passwordHash, row.user_id]);
    await pool.query('UPDATE password_reset_tokens SET used_at=NOW() WHERE user_id=$1 AND used_at IS NULL', [row.user_id]);
    await pool.query('COMMIT');
    res.json({ message: 'Password updated. You can now sign in.' });
  } catch (e) {
    try { await pool.query('ROLLBACK'); } catch {}
    console.error(e); res.status(500).json({ error: 'Could not reset password.' });
  }
});

app.get('/api/auth/me', (req, res) => res.json({ user: req.user ? publicUser(req.user) : null }));

app.get('/api/security/2fa/setup', requireAuth, async (req, res) => {
  try {
    const secret = authenticator.generateSecret();
    req.session.pending2FASecret = secret;
    const label = encodeURIComponent(`DecisionWise:${req.user.email}`);
    const issuer = encodeURIComponent('DecisionWise');
    const otpauth = `otpauth://totp/${label}?secret=${secret}&issuer=${issuer}`;
    const qrDataUrl = await QRCode.toDataURL(otpauth);
    res.json({ secret, qrDataUrl, message: 'Scan the QR code with an authenticator app, then verify a current code to enable 2FA.' });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Could not prepare two-factor setup.' }); }
});

app.post('/api/security/2fa/enable', requireAuth, async (req, res) => {
  const secret = req.session.pending2FASecret;
  const code = String(req.body.code || '');
  if (!secret) return res.status(400).json({ error: 'Start 2FA setup first.' });
  if (!authenticator.check(code, secret)) return res.status(400).json({ error: 'That code is not valid. Try the current code in your authenticator app.' });
  await pool.query('UPDATE users SET two_factor_secret=$1,two_factor_enabled=TRUE WHERE id=$2', [secret, req.user.id]);
  delete req.session.pending2FASecret;
  res.json({ message: 'Two-factor authentication is enabled.' });
});

app.post('/api/security/2fa/disable', requireAuth, async (req, res) => {
  const password = String(req.body.password || '');
  const code = String(req.body.code || '');
  const result = await pool.query('SELECT * FROM users WHERE id=$1', [req.user.id]);
  const user = result.rows[0];
  if (!user.password_hash || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: 'Enter your current password to disable 2FA.' });
  }
  if (!authenticator.check(code, user.two_factor_secret || '')) return res.status(400).json({ error: 'Enter a valid authenticator code.' });
  await pool.query('UPDATE users SET two_factor_secret=NULL,two_factor_enabled=FALSE WHERE id=$1', [req.user.id]);
  res.json({ message: 'Two-factor authentication is disabled.' });
});

app.get('/api/security/status', requireAuth, (req, res) => {
  res.json({ twoFactorEnabled: Boolean(req.user.two_factor_enabled), email: req.user.email });
});

app.get('/health', (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`DecisionWise auth starter listening on ${APP_URL}`));
